import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

export function GlowCard({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "glass rounded-2xl p-6 transition-all hover:ring-aurora hover:-translate-y-0.5",
        className,
      )}
      {...props}
    />
  );
}
