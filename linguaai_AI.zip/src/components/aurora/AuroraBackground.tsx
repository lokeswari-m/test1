export function AuroraBackground() {
  return (
    <div className="aurora-bg" aria-hidden>
      <div className="blob-mid" />
    </div>
  );
}
