import { Link, useRouterState } from "@tanstack/react-router";
import { Sparkles, MessageSquare, Mic, Languages, Briefcase, LayoutDashboard, History, LogOut, LogIn } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/layout/ThemeToggle";

const nav = [
  { to: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/chat", icon: MessageSquare, label: "AI Chat" },
  { to: "/voice", icon: Mic, label: "Voice Practice" },
  { to: "/telugu", icon: Languages, label: "Telugu → English" },
  { to: "/interview", icon: Briefcase, label: "Mock Interview" },
  { to: "/history", icon: History, label: "History" },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { user, isGuest, signOut } = useAuth();

  return (
    <div className="min-h-screen flex w-full">
      <aside className="hidden md:flex w-64 flex-col border-r border-border/50 glass">
        <Link to="/" className="flex items-center gap-2 px-5 py-5">
          <span className="grid place-items-center w-9 h-9 rounded-xl bg-gradient-aurora">
            <Sparkles className="w-5 h-5 text-background" />
          </span>
          <div>
            <div className="font-semibold tracking-tight">LinguaAI</div>
            <div className="text-xs text-muted-foreground font-mono-display">v1.0</div>
          </div>
        </Link>
        <nav className="flex-1 px-3 space-y-1">
          {nav.map((n) => {
            const active = path.startsWith(n.to);
            return (
              <Link
                key={n.to}
                to={n.to}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                  active
                    ? "bg-gradient-aurora text-background font-medium shadow-lg"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/60"
                }`}
              >
                <n.icon className="w-4 h-4" />
                {n.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-border/50 space-y-2">
          {user ? (
            <>
              <div className="text-xs text-muted-foreground px-2">
                {isGuest ? "Guest mode" : user.email}
              </div>
              <Button variant="ghost" size="sm" className="w-full justify-start" onClick={signOut}>
                <LogOut className="w-4 h-4 mr-2" /> Sign out
              </Button>
            </>
          ) : (
            <Link to="/login">
              <Button variant="ghost" size="sm" className="w-full justify-start">
                <LogIn className="w-4 h-4 mr-2" /> Sign in
              </Button>
            </Link>
          )}
          <ThemeToggle />
        </div>
      </aside>

      <main className="flex-1 min-w-0">
        <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-border/50 glass">
          <Link to="/" className="flex items-center gap-2">
            <span className="grid place-items-center w-8 h-8 rounded-lg bg-gradient-aurora">
              <Sparkles className="w-4 h-4 text-background" />
            </span>
            <span className="font-semibold">LinguaAI</span>
          </Link>
          <ThemeToggle />
        </div>
        <div className="md:hidden flex gap-1 overflow-x-auto px-3 py-2 border-b border-border/50">
          {nav.map((n) => {
            const active = path.startsWith(n.to);
            return (
              <Link
                key={n.to}
                to={n.to}
                className={`shrink-0 px-3 py-1.5 rounded-md text-xs ${
                  active ? "bg-gradient-aurora text-background" : "text-muted-foreground"
                }`}
              >
                {n.label}
              </Link>
            );
          })}
        </div>
        {children}
      </main>
    </div>
  );
}
