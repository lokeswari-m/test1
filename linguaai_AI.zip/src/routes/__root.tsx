import { Outlet, createRootRoute, HeadContent, Scripts, Link } from "@tanstack/react-router";
import { AuroraBackground } from "@/components/aurora/AuroraBackground";
import { AuthProvider } from "@/lib/auth";
import { Toaster } from "@/components/ui/sonner";
import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="min-h-screen grid place-items-center px-4">
      <div className="text-center">
        <h1 className="text-7xl font-bold text-gradient-aurora">404</h1>
        <p className="mt-3 text-muted-foreground">This page is off-route.</p>
        <Link to="/" className="inline-block mt-6 px-5 py-2.5 rounded-lg bg-gradient-aurora text-background font-medium">
          Go home
        </Link>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "LinguaAI — Master English with AI" },
      { name: "description", content: "Free AI-powered English learning for speaking fluency, interview prep, and Telugu→English help." },
      { name: "theme-color", content: "#0e1024" },
      { property: "og:title", content: "LinguaAI — Master English with AI" },
      { property: "og:description", content: "Free AI-powered English learning for speaking fluency, interview prep, and Telugu→English help." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "LinguaAI — Master English with AI" },
      { name: "twitter:description", content: "Free AI-powered English learning for speaking fluency, interview prep, and Telugu→English help." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/6177917d-dc3a-40da-b829-3040703f3121" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/6177917d-dc3a-40da-b829-3040703f3121" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <HeadContent />
        <script
          dangerouslySetInnerHTML={{
            __html: `try{var t=localStorage.getItem('aet:theme');if(t==='light'){document.documentElement.classList.remove('dark');document.documentElement.classList.add('light');}}catch(e){}`,
          }}
        />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <AuthProvider>
      <AuroraBackground />
      <Outlet />
      <Toaster />
    </AuthProvider>
  );
}
