import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GlowCard } from "@/components/aurora/GlowCard";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  component: LoginPage,
  head: () => ({ meta: [{ title: "Sign in — LinguaAI" }] }),
});

function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  const { signInAsGuest } = useAuth();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Welcome back!");
    navigate({ to: "/dashboard" });
  }

  async function google() {
    setBusy(true);
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/dashboard" });
    if (result.error) {
      setBusy(false);
      return toast.error("Could not sign in with Google");
    }
    if (result.redirected) return;
    navigate({ to: "/dashboard" });
  }

  async function guest() {
    setBusy(true);
    await signInAsGuest();
    setBusy(false);
    navigate({ to: "/dashboard" });
  }

  return (
    <div className="min-h-screen grid place-items-center px-4">
      <div className="w-full max-w-md">
        <Link to="/" className="flex items-center gap-2 justify-center mb-6">
          <span className="grid place-items-center w-9 h-9 rounded-xl bg-gradient-aurora">
            <Sparkles className="w-5 h-5 text-background" />
          </span>
          <span className="font-semibold text-lg">LinguaAI</span>
        </Link>
        <GlowCard>
          <h1 className="text-2xl font-bold tracking-tight">Welcome back</h1>
          <p className="text-sm text-muted-foreground mt-1">Sign in to continue learning.</p>
          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            <Button type="submit" disabled={busy} className="w-full bg-gradient-aurora text-background hover:opacity-90">
              Sign in
            </Button>
          </form>
          <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
            <div className="flex-1 h-px bg-border" /> or <div className="flex-1 h-px bg-border" />
          </div>
          <Button type="button" variant="outline" onClick={google} disabled={busy} className="w-full">
            Continue with Google
          </Button>
          <Button type="button" variant="ghost" onClick={guest} disabled={busy} className="w-full mt-2">
            Continue as guest
          </Button>
          <p className="mt-5 text-sm text-center text-muted-foreground">
            New here? <Link to="/signup" className="text-aurora-pink hover:underline">Create an account</Link>
          </p>
        </GlowCard>
      </div>
    </div>
  );
}
