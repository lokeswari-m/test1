import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, MessageSquare, Mic, Languages, Briefcase, Zap, Star, ArrowRight } from "lucide-react";
import { GlowCard } from "@/components/aurora/GlowCard";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  component: Landing,
  head: () => ({
    meta: [
      { title: "LinguaAI — Master English with AI" },
      { name: "description", content: "Speak English confidently with a free AI tutor. Voice practice, mock interviews, Telugu→English help." },
    ],
  }),
});

const features = [
  { icon: MessageSquare, title: "AI Conversation", desc: "Chat with an AI tutor that corrects grammar and suggests fluent phrasing in real time." },
  { icon: Mic, title: "Voice Speaking", desc: "Practice aloud with your microphone. Get fluency, grammar and vocabulary scores." },
  { icon: Languages, title: "Telugu → English", desc: "Type or speak in Telugu. See literal and fluent English with mistakes explained." },
  { icon: Briefcase, title: "Mock Interviews", desc: "HR, Technical, and General interviews with per-answer AI feedback and a confidence score." },
];

const testimonials = [
  { name: "Anitha R.", role: "Software trainee", quote: "I cleared my first HR round after one week of mock interviews. Game changer." },
  { name: "Rahul K.", role: "B.Tech student", quote: "The Telugu helper is exactly what I needed. I think in Telugu and speak in English now." },
  { name: "Priya S.", role: "Job seeker", quote: "Voice practice made me realize my filler words. Score went from 52 to 84." },
];

function Landing() {
  return (
    <div className="min-h-screen">
      {/* Nav */}
      <header className="container mx-auto px-6 py-5 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <span className="grid place-items-center w-9 h-9 rounded-xl bg-gradient-aurora">
            <Sparkles className="w-5 h-5 text-background" />
          </span>
          <span className="font-semibold tracking-tight text-lg">LinguaAI</span>
        </Link>
        <nav className="flex items-center gap-2">
          <Link to="/login"><Button variant="ghost" size="sm">Sign in</Button></Link>
          <Link to="/signup"><Button size="sm" className="bg-gradient-aurora text-background hover:opacity-90">Get started</Button></Link>
        </nav>
      </header>

      {/* Hero */}
      <section className="container mx-auto px-6 pt-16 pb-24 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs font-mono-display mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-aurora-teal animate-pulse" />
          100% free • Powered by AI
        </div>
        <h1 className="text-5xl sm:text-7xl font-bold tracking-tighter leading-[1.05] max-w-4xl mx-auto">
          Master <span className="text-gradient-aurora">English</span> with AI
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
          A futuristic AI tutor that listens, corrects, and coaches you to speak with confidence — for conversations, interviews, and beyond.
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
          <Link to="/signup">
            <Button size="lg" className="bg-gradient-aurora text-background hover:opacity-90 text-base h-12 px-6">
              Start Learning <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
          <Link to="/chat">
            <Button size="lg" variant="outline" className="text-base h-12 px-6 glass border-border/60">
              <MessageSquare className="mr-2 w-4 h-4" /> Try AI Chat
            </Button>
          </Link>
        </div>
        <div className="mt-6 text-xs text-muted-foreground font-mono-display">
          No credit card • Guest mode available
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">An entire English program in one app</h2>
          <p className="mt-3 text-muted-foreground">Everything you need to go from hesitant to fluent.</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((f) => (
            <GlowCard key={f.title} className="text-left">
              <div className="w-10 h-10 rounded-lg bg-gradient-aurora grid place-items-center mb-4">
                <f.icon className="w-5 h-5 text-background" />
              </div>
              <h3 className="font-semibold text-lg">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
            </GlowCard>
          ))}
        </div>
      </section>

      {/* Stats / Why */}
      <section className="container mx-auto px-6 py-16">
        <div className="grid md:grid-cols-3 gap-5">
          {[
            { k: "Free forever", v: "No paywall. No subscription.", icon: Zap },
            { k: "Real-time AI", v: "Instant correction & feedback", icon: Sparkles },
            { k: "Built for India", v: "Telugu speakers welcome", icon: Languages },
          ].map((s) => (
            <GlowCard key={s.k} className="flex items-center gap-4">
              <s.icon className="w-8 h-8 text-aurora-pink" />
              <div>
                <div className="font-semibold">{s.k}</div>
                <div className="text-sm text-muted-foreground">{s.v}</div>
              </div>
            </GlowCard>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="container mx-auto px-6 py-16">
        <div className="text-center mb-10">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">Learners shipping confidence</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-5">
          {testimonials.map((t) => (
            <GlowCard key={t.name}>
              <div className="flex gap-1 mb-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-aurora-pink text-aurora-pink" />
                ))}
              </div>
              <p className="text-sm">&ldquo;{t.quote}&rdquo;</p>
              <div className="mt-4 text-xs font-mono-display text-muted-foreground">
                {t.name} • {t.role}
              </div>
            </GlowCard>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-6 py-20">
        <GlowCard className="text-center py-14">
          <h2 className="text-3xl sm:text-5xl font-bold tracking-tight">
            Your <span className="text-gradient-aurora">AI tutor</span> is ready.
          </h2>
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            Start a session in 10 seconds. No setup. No credit card.
          </p>
          <Link to="/signup" className="inline-block mt-8">
            <Button size="lg" className="bg-gradient-aurora text-background hover:opacity-90 h-12 px-8">
              Start free <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </GlowCard>
      </section>

      <footer className="mt-10">
        <div className="h-px w-full bg-gradient-aurora opacity-60" />
        <div className="container mx-auto px-6 py-10 text-center space-y-2">
          <div className="text-lg sm:text-xl font-semibold tracking-tight text-gradient-aurora">
            Founded by Lokeswari Manchem
          </div>
          <div className="text-sm text-muted-foreground font-mono-display">
            Built with AI for English learners
          </div>
          <div className="text-xs text-muted-foreground/70 font-mono-display pt-2">
            © {new Date().getFullYear()} · LinguaAI
          </div>
        </div>
      </footer>
    </div>
  );
}
