import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mic, MicOff, Loader2, Languages, Sparkles } from "lucide-react";
import { GlowCard } from "@/components/aurora/GlowCard";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useServerFn } from "@tanstack/react-start";
import { teluguHelper } from "@/server/ai.functions";
import { useSpeechRecognition, speak } from "@/hooks/useSpeechRecognition";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/telugu")({
  component: TeluguPage,
  head: () => ({ meta: [{ title: "Telugu → English — LinguaAI" }] }),
});

type Out = Awaited<ReturnType<ReturnType<typeof useServerFn<typeof teluguHelper>>>>;

function TeluguPage() {
  const fn = useServerFn(teluguHelper);
  const { supported, listening, transcript, interim, start, stop, reset, setTranscript } = useSpeechRecognition("te-IN");
  const [busy, setBusy] = useState(false);
  const [out, setOut] = useState<Out | null>(null);

  async function go() {
    const text = transcript.trim();
    if (!text) return toast.error("Type or speak in Telugu first.");
    setBusy(true);
    setOut(null);
    try {
      const r = await fn({ data: { input: text } });
      setOut(r);
    } catch (e: any) {
      toast.error(e?.message || "Could not translate");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container mx-auto px-6 py-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-aurora grid place-items-center">
          <Languages className="w-5 h-5 text-background" />
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Telugu → English</h1>
          <p className="text-sm text-muted-foreground">Type or speak Telugu (script or roman). Get fluent English back.</p>
        </div>
      </div>

      <GlowCard className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <div className="text-sm font-medium">Your input (Telugu)</div>
          <div className="flex gap-2">
            {supported && (
              <Button size="sm" variant={listening ? "destructive" : "outline"} onClick={listening ? stop : start} className={listening ? "animate-pulse-glow" : ""}>
                {listening ? <><MicOff className="w-4 h-4 mr-1.5" /> Stop</> : <><Mic className="w-4 h-4 mr-1.5" /> Speak Telugu</>}
              </Button>
            )}
            <Button size="sm" variant="ghost" onClick={() => { reset(); setOut(null); }}>Clear</Button>
          </div>
        </div>
        <Textarea
          value={transcript + (interim ? " " + interim : "")}
          onChange={(e) => setTranscript(e.target.value)}
          placeholder="నేను నీళ్లు తాగుతున్నాను… or 'nenu coffee taguthunnanu'"
          rows={4}
        />
        <div className="flex justify-end mt-3">
          <Button onClick={go} disabled={busy} className="bg-gradient-aurora text-background">
            {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
            Convert to English
          </Button>
        </div>
      </GlowCard>

      {out && (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
          <Row label="Telugu (script)" value={out.teluguScript} />
          <Row label="Transliteration" value={out.transliteration} mono />
          <Row label="Literal English" value={out.literalEnglish} accent="pink" />
          <GlowCard className="border-l-2 border-aurora-teal">
            <div className="flex items-center justify-between">
              <div className="text-xs font-mono-display text-aurora-teal mb-2">FLUENT ENGLISH ✨</div>
              <Button size="sm" variant="ghost" onClick={() => speak(out.fluentEnglish)}>🔊 Hear it</Button>
            </div>
            <div className="text-lg font-semibold">{out.fluentEnglish}</div>
          </GlowCard>
          <GlowCard>
            <div className="text-xs font-mono-display text-muted-foreground mb-2">EXPLANATION</div>
            <p className="text-sm">{out.explanation}</p>
          </GlowCard>
          {out.tips.length > 0 && (
            <GlowCard className="border-l-2 border-aurora-purple">
              <div className="text-xs font-mono-display text-aurora-purple mb-2">TIPS</div>
              <ul className="text-sm space-y-1.5 list-disc list-inside">
                {out.tips.map((t: string, i: number) => <li key={i}>{t}</li>)}
              </ul>
            </GlowCard>
          )}
        </div>
      )}
    </div>
  );
}

function Row({ label, value, mono, accent }: { label: string; value: string; mono?: boolean; accent?: "pink" | "teal" }) {
  const border = accent === "pink" ? "border-aurora-pink" : accent === "teal" ? "border-aurora-teal" : "";
  return (
    <GlowCard className={accent ? `border-l-2 ${border}` : ""}>
      <div className="text-xs font-mono-display text-muted-foreground mb-1.5">{label}</div>
      <div className={mono ? "font-mono-display text-sm" : ""}>{value}</div>
    </GlowCard>
  );
}
