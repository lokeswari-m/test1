import { createFileRoute } from "@tanstack/react-router";
import { useState, useRef, useEffect } from "react";
import { Send, Mic, MicOff, Sparkles, CheckCircle2, Wand2, Loader2 } from "lucide-react";
import { GlowCard } from "@/components/aurora/GlowCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useServerFn } from "@tanstack/react-start";
import { chatTutor } from "@/server/ai.functions";
import { useSpeechRecognition, speak } from "@/hooks/useSpeechRecognition";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/chat")({
  component: ChatPage,
  head: () => ({ meta: [{ title: "AI Chat — LinguaAI" }] }),
});

type Msg = { role: "user" | "assistant"; content: string; correction?: string; better?: string };

function ChatPage() {
  const fn = useServerFn(chatTutor);
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Hi! I'm your AI English tutor. What would you like to talk about today?" },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { listening, transcript, supported, start, stop, reset } = useSpeechRecognition("en-US");

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  useEffect(() => {
    if (!listening && transcript) {
      setInput((p) => (p ? p + " " : "") + transcript);
      reset();
    }
  }, [listening, transcript, reset]);

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    const next = [...messages, { role: "user" as const, content: text }];
    setMessages(next);
    setBusy(true);
    try {
      const out = await fn({
        data: {
          history: next.slice(-20).map((m) => ({ role: m.role, content: m.content })),
          level: "beginner",
        },
      });
      const reply: Msg = {
        role: "assistant",
        content: out.reply,
        correction: out.correction || undefined,
        better: out.betterPhrasing || undefined,
      };
      setMessages((m) => [...m, reply]);
      speak(out.reply);
    } catch (e: any) {
      toast.error(e?.message || "Could not reach AI");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 py-6 max-w-4xl flex flex-col h-[calc(100vh-4rem)] md:h-screen">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-gradient-aurora grid place-items-center">
          <Sparkles className="w-5 h-5 text-background" />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight">AI Conversation</h1>
          <p className="text-xs text-muted-foreground">Speak or type — I'll correct your grammar instantly.</p>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-4 pb-4 pr-1">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[85%] ${m.role === "user" ? "" : "space-y-2"}`}>
              <div
                className={
                  m.role === "user"
                    ? "px-4 py-2.5 rounded-2xl bg-gradient-aurora text-background"
                    : "px-4 py-2.5 rounded-2xl glass"
                }
              >
                {m.content}
              </div>
              {m.correction && (
                <GlowCard className="!p-3 border-l-2 border-aurora-pink">
                  <div className="text-xs font-mono-display text-aurora-pink flex items-center gap-1.5 mb-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Correction
                  </div>
                  <div className="text-sm">{m.correction}</div>
                </GlowCard>
              )}
              {m.better && (
                <GlowCard className="!p-3 border-l-2 border-aurora-teal">
                  <div className="text-xs font-mono-display text-aurora-teal flex items-center gap-1.5 mb-1">
                    <Wand2 className="w-3.5 h-3.5" /> Better way to say it
                  </div>
                  <div className="text-sm">{m.better}</div>
                </GlowCard>
              )}
            </div>
          </div>
        ))}
        {busy && (
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <Loader2 className="w-4 h-4 animate-spin" /> Thinking…
          </div>
        )}
      </div>

      <div className="flex gap-2 pt-2 border-t border-border/50">
        {supported && (
          <Button
            type="button"
            variant={listening ? "destructive" : "outline"}
            size="icon"
            onClick={listening ? stop : start}
            className={listening ? "animate-pulse-glow" : ""}
            title={listening ? "Stop" : "Speak"}
          >
            {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </Button>
        )}
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder={listening ? "Listening…" : "Type or speak in English"}
          disabled={busy}
        />
        <Button onClick={send} disabled={busy || !input.trim()} className="bg-gradient-aurora text-background">
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
