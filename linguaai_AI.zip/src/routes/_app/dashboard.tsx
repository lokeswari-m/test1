import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { MessageSquare, Mic, Languages, Briefcase, Flame, Trophy, Sparkles } from "lucide-react";
import { GlowCard } from "@/components/aurora/GlowCard";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_app/dashboard")({
  component: Dashboard,
  head: () => ({ meta: [{ title: "Dashboard — LinguaAI" }] }),
});

const quickActions = [
  { to: "/chat", icon: MessageSquare, title: "Talk with AI", desc: "Free conversation with corrections", color: "from-aurora-teal to-aurora-purple" },
  { to: "/voice", icon: Mic, title: "Voice Practice", desc: "Speak aloud, get a fluency score", color: "from-aurora-purple to-aurora-pink" },
  { to: "/telugu", icon: Languages, title: "Telugu → English", desc: "Speak Telugu, learn fluent English", color: "from-aurora-teal to-aurora-pink" },
  { to: "/interview", icon: Briefcase, title: "Mock Interview", desc: "HR, Tech & General — with AI feedback", color: "from-aurora-pink to-aurora-purple" },
];

function Dashboard() {
  const { user, isGuest } = useAuth();
  const [profile, setProfile] = useState<{ display_name: string | null; streak_count: number; points: number; level: string } | null>(null);
  const [sessionCount, setSessionCount] = useState(0);

  useEffect(() => {
    if (!user) return;
    if (isGuest) {
      setProfile({ display_name: "Guest", streak_count: 0, points: 0, level: "beginner" });
      return;
    }
    supabase.from("profiles").select("display_name,streak_count,points,level").eq("id", user.id).maybeSingle().then(({ data }) => {
      setProfile(data ?? { display_name: null, streak_count: 0, points: 0, level: "beginner" });
    });
    supabase.from("sessions").select("id", { count: "exact", head: true }).eq("user_id", user.id).then(({ count }) => {
      setSessionCount(count ?? 0);
    });
  }, [user, isGuest]);

  const name = profile?.display_name || (isGuest ? "Guest" : user?.email?.split("@")[0]) || "Learner";

  return (
    <div className="container mx-auto px-6 py-10 max-w-6xl">
      {isGuest && (
        <GlowCard className="mb-6 flex flex-wrap items-center gap-3 justify-between">
          <div className="text-sm">
            <span className="font-semibold">You're in guest mode.</span>
            <span className="text-muted-foreground ml-1">Create an account to save progress, history and streaks.</span>
          </div>
          <Link to="/signup" className="px-4 py-2 rounded-lg bg-gradient-aurora text-background text-sm font-medium">
            Save my progress
          </Link>
        </GlowCard>
      )}

      <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
        <div>
          <div className="text-xs font-mono-display text-muted-foreground">{new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</div>
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight mt-1">
            Hey, <span className="text-gradient-aurora">{name}</span> 👋
          </h1>
          <p className="text-muted-foreground mt-1">Your AI tutor is ready. Pick a session below.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <GlowCard className="!p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><Flame className="w-4 h-4 text-aurora-pink" />Streak</div>
          <div className="text-2xl font-bold mt-1">{profile?.streak_count ?? 0}<span className="text-sm text-muted-foreground ml-1">days</span></div>
        </GlowCard>
        <GlowCard className="!p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><Trophy className="w-4 h-4 text-aurora-teal" />Points</div>
          <div className="text-2xl font-bold mt-1">{profile?.points ?? 0}</div>
        </GlowCard>
        <GlowCard className="!p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><Sparkles className="w-4 h-4 text-aurora-purple" />Level</div>
          <div className="text-2xl font-bold mt-1 capitalize">{profile?.level ?? "beginner"}</div>
        </GlowCard>
        <GlowCard className="!p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><MessageSquare className="w-4 h-4 text-aurora-pink" />Sessions</div>
          <div className="text-2xl font-bold mt-1">{sessionCount}</div>
        </GlowCard>
      </div>

      <h2 className="text-xl font-semibold mb-4">Quick actions</h2>
      <div className="grid sm:grid-cols-2 gap-4">
        {quickActions.map((q) => (
          <Link key={q.to} to={q.to}>
            <GlowCard className="cursor-pointer h-full">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${q.color} grid place-items-center mb-4`}>
                <q.icon className="w-6 h-6 text-background" />
              </div>
              <div className="font-semibold text-lg">{q.title}</div>
              <div className="text-sm text-muted-foreground mt-1">{q.desc}</div>
            </GlowCard>
          </Link>
        ))}
      </div>

      <h2 className="text-xl font-semibold mt-10 mb-4">AI recommendation</h2>
      <GlowCard>
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-aurora grid place-items-center shrink-0">
            <Sparkles className="w-5 h-5 text-background" />
          </div>
          <div>
            <div className="font-semibold">Today's focus: introduce yourself confidently</div>
            <p className="text-sm text-muted-foreground mt-1">
              Try a 2-minute voice practice on the topic <em>"Tell me about yourself"</em>, then run one HR mock interview to lock it in.
            </p>
            <div className="mt-4 flex gap-2">
              <Link to="/voice" className="px-4 py-2 rounded-lg bg-gradient-aurora text-background text-sm font-medium">Start voice practice</Link>
              <Link to="/interview" className="px-4 py-2 rounded-lg glass text-sm">Start interview</Link>
            </div>
          </div>
        </div>
      </GlowCard>
    </div>
  );
}
