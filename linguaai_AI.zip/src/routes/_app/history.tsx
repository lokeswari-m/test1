import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { History as HistoryIcon } from "lucide-react";
import { GlowCard } from "@/components/aurora/GlowCard";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_app/history")({
  component: HistoryPage,
  head: () => ({ meta: [{ title: "History — LinguaAI" }] }),
});

type Row = { id: string; type: string; title: string | null; summary: string | null; score: number | null; created_at: string };

function HistoryPage() {
  const { user, isGuest } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || isGuest) { setLoading(false); return; }
    supabase.from("sessions").select("id,type,title,summary,score,created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(50).then(({ data }) => {
      setRows((data ?? []) as Row[]);
      setLoading(false);
    });
  }, [user, isGuest]);

  return (
    <div className="container mx-auto px-6 py-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-aurora grid place-items-center">
          <HistoryIcon className="w-5 h-5 text-background" />
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">History</h1>
          <p className="text-sm text-muted-foreground">Your saved sessions and progress.</p>
        </div>
      </div>

      {isGuest ? (
        <GlowCard>
          <div className="text-sm">Guest mode doesn't save history. Create an account to keep your progress.</div>
        </GlowCard>
      ) : loading ? (
        <GlowCard><div className="text-sm text-muted-foreground">Loading…</div></GlowCard>
      ) : rows.length === 0 ? (
        <GlowCard>
          <div className="text-sm text-muted-foreground">
            No sessions yet. Start a chat, voice practice, or interview — they'll show up here.
          </div>
        </GlowCard>
      ) : (
        <div className="space-y-3">
          {rows.map((r) => (
            <GlowCard key={r.id} className="!p-4 flex items-center justify-between">
              <div>
                <div className="text-xs font-mono-display text-muted-foreground uppercase">{r.type}</div>
                <div className="font-medium">{r.title || r.summary || "Session"}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{new Date(r.created_at).toLocaleString()}</div>
              </div>
              {r.score != null && (
                <div className="text-2xl font-bold text-gradient-aurora">{r.score}</div>
              )}
            </GlowCard>
          ))}
        </div>
      )}
    </div>
  );
}
