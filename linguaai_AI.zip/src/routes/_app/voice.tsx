import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mic, MicOff, Loader2, Sparkles, RefreshCw } from "lucide-react";
import { GlowCard } from "@/components/aurora/GlowCard";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useServerFn } from "@tanstack/react-start";
import { voiceFeedback } from "@/server/ai.functions";
import { useSpeechRecognition } from "@/hooks/useSpeechRecognition";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/_app/voice")({
  component: VoicePage,
  head: () => ({ meta: [{ title: "Voice Practice — LinguaAI" }] }),
});

const TOPICS = [
  "Tell me about yourself",
  "Describe your hometown",
  "A challenge you overcame",
  "Your favorite hobby and why",
  "Where do you see yourself in 5 years?",
  "Talk about a memorable trip",
];

type FB = Awaited<ReturnType<ReturnType<typeof useServerFn<typeof voiceFeedback>>>>;

function VoicePage() {
  const fn = useServerFn(voiceFeedback);
  const [topic, setTopic] = useState(TOPICS[0]);
  const { supported, listening, transcript, interim, start, stop, reset, setTranscript } = useSpeechRecognition("en-US");
  const [busy, setBusy] = useState(false);
  const [fb, setFb] = useState<FB | null>(null);

  async function analyze() {
    if (!transcript.trim()) return toast.error("Speak or type something first.");
    setBusy(true);
    setFb(null);
    try {
      const out = await fn({ data: { topic, transcript } });
      setFb(out);
    } catch (e: any) {
      toast.error(e?.message || "Could not analyze");
    } finally {
      setBusy(false);
    }
  }

  function clear() {
    reset();
    setFb(null);
  }

  return (
    <div className="container mx-auto px-6 py-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-aurora grid place-items-center">
          <Mic className="w-5 h-5 text-background" />
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Voice Practice</h1>
          <p className="text-sm text-muted-foreground">Pick a topic, hit the mic, speak naturally.</p>
        </div>
      </div>

      {!supported && (
        <GlowCard className="mb-6 border-l-2 border-aurora-pink">
          <div className="text-sm">
            Your browser doesn't support speech recognition. Try Chrome or Edge, or type your answer manually below.
          </div>
        </GlowCard>
      )}

      <GlowCard className="mb-6">
        <div className="text-xs font-mono-display text-muted-foreground mb-2">TOPIC</div>
        <div className="flex flex-wrap gap-2 mb-4">
          {TOPICS.map((t) => (
            <button
              key={t}
              onClick={() => setTopic(t)}
              className={`text-xs px-3 py-1.5 rounded-full transition ${
                topic === t ? "bg-gradient-aurora text-background" : "glass hover:ring-aurora"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="text-lg font-semibold">{topic}</div>
      </GlowCard>

      <GlowCard className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <div className="text-sm font-medium">Your response</div>
          <div className="flex gap-2">
            {supported && (
              <Button
                size="sm"
                variant={listening ? "destructive" : "outline"}
                onClick={listening ? stop : start}
                className={listening ? "animate-pulse-glow" : ""}
              >
                {listening ? <><MicOff className="w-4 h-4 mr-1.5" /> Stop</> : <><Mic className="w-4 h-4 mr-1.5" /> Speak</>}
              </Button>
            )}
            <Button size="sm" variant="ghost" onClick={clear}><RefreshCw className="w-4 h-4 mr-1.5" />Clear</Button>
          </div>
        </div>
        <Textarea
          value={transcript + (interim ? " " + interim : "")}
          onChange={(e) => setTranscript(e.target.value)}
          placeholder={listening ? "Listening… speak now" : "Click Speak above, or type your answer here."}
          rows={6}
          className="resize-none"
        />
        <div className="flex justify-end mt-3">
          <Button onClick={analyze} disabled={busy} className="bg-gradient-aurora text-background">
            {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
            Analyze my response
          </Button>
        </div>
      </GlowCard>

      {fb && (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
          <div className="grid grid-cols-3 gap-4">
            <Score label="Fluency" value={fb.fluencyScore} />
            <Score label="Grammar" value={fb.grammarScore} />
            <Score label="Vocabulary" value={fb.vocabScore} />
          </div>
          <GlowCard>
            <div className="text-sm font-semibold mb-2">Summary</div>
            <p className="text-sm text-muted-foreground">{fb.summary}</p>
          </GlowCard>
          {fb.issues.length > 0 && (
            <GlowCard className="border-l-2 border-aurora-pink">
              <div className="text-xs font-mono-display text-aurora-pink mb-2">ISSUES</div>
              <ul className="text-sm space-y-1.5 list-disc list-inside">
                {fb.issues.map((s: string, i: number) => <li key={i}>{s}</li>)}
              </ul>
            </GlowCard>
          )}
          {fb.suggestions.length > 0 && (
            <GlowCard className="border-l-2 border-aurora-teal">
              <div className="text-xs font-mono-display text-aurora-teal mb-2">SUGGESTIONS</div>
              <ul className="text-sm space-y-1.5 list-disc list-inside">
                {fb.suggestions.map((s: string, i: number) => <li key={i}>{s}</li>)}
              </ul>
            </GlowCard>
          )}
          <GlowCard className="border-l-2 border-aurora-purple">
            <div className="text-xs font-mono-display text-aurora-purple mb-2">MODEL ANSWER</div>
            <p className="text-sm">{fb.modelAnswer}</p>
          </GlowCard>
        </div>
      )}
    </div>
  );
}

function Score({ label, value }: { label: string; value: number }) {
  return (
    <GlowCard className="!p-4 text-center">
      <div className="text-xs font-mono-display text-muted-foreground">{label}</div>
      <div className="text-3xl font-bold text-gradient-aurora my-1">{value}</div>
      <Progress value={value} className="h-1.5" />
    </GlowCard>
  );
}
