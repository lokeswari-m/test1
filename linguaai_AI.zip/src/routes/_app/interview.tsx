import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect, useRef } from "react";
import {
  Briefcase, Mic, MicOff, Send, Loader2, Sparkles, RefreshCw, Play,
  Code2, Coffee, Cpu, Database, Braces, Brain, Globe, Network, Server, Boxes, ArrowLeft,
} from "lucide-react";
import { GlowCard } from "@/components/aurora/GlowCard";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useServerFn } from "@tanstack/react-start";
import { interviewNextQuestion, interviewFeedback } from "@/server/ai.functions";
import {
  getActiveInterview,
  saveInterviewTurn,
  restartInterview,
} from "@/server/interview.functions";
import { useSpeechRecognition, speak } from "@/hooks/useSpeechRecognition";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/_app/interview")({
  component: InterviewPage,
  head: () => ({ meta: [{ title: "Mock Interview — LinguaAI" }] }),
});

type Category = "HR" | "Technical" | "General";
type Difficulty = "easy" | "medium" | "hard";
type CompanyStyle = "product" | "service" | "startup";

type Turn = {
  question: string;
  answer?: string;
  feedback?: any;
};

const TARGET_QUESTIONS = 30;

const CORE_DOMAINS = [
  { name: "C Programming", icon: Cpu },
  { name: "Python", icon: Code2 },
  { name: "Java", icon: Coffee },
  { name: "DSA", icon: Boxes },
  { name: "DBMS", icon: Database },
] as const;

const MORE_DOMAINS = [
  { name: "Operating Systems", icon: Server },
  { name: "Computer Networks", icon: Network },
  { name: "Web Development", icon: Globe },
  { name: "SQL", icon: Database },
  { name: "React", icon: Braces },
  { name: "Machine Learning", icon: Brain },
] as const;

function normalizeQ(q: string) {
  return q.trim().toLowerCase().slice(0, 120);
}

function diffBadgeClass(d: Difficulty) {
  if (d === "easy") return "bg-aurora-teal/15 text-aurora-teal";
  if (d === "medium") return "bg-aurora-purple/15 text-aurora-purple";
  return "bg-aurora-pink/15 text-aurora-pink";
}

function InterviewPage() {
  const askFn = useServerFn(interviewNextQuestion);
  const fbFn = useServerFn(interviewFeedback);
  const getActive = useServerFn(getActiveInterview);
  const saveTurn = useServerFn(saveInterviewTurn);
  const restartFn = useServerFn(restartInterview);

  const [category, setCategory] = useState<Category>("HR");
  const [domain, setDomain] = useState<string | null>(null);
  const [showMore, setShowMore] = useState(false);
  const [companyStyle, setCompanyStyle] = useState<CompanyStyle>("product");
  const [autoRamp, setAutoRamp] = useState(true);
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [started, setStarted] = useState(false);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [askedQuestions, setAskedQuestions] = useState<string[]>([]);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [resumed, setResumed] = useState(false);
  const [hasActive, setHasActive] = useState(false);
  const [answer, setAnswer] = useState("");
  const [busy, setBusy] = useState(false);
  const [hydrating, setHydrating] = useState(false);
  const { supported, listening, transcript, interim, start, stop, reset } = useSpeechRecognition("en-US");
  const lastCheck = useRef<string>("");

  const needsDomain = category === "Technical";
  const canConfigure = !needsDomain || !!domain;

  useEffect(() => {
    if (!listening && transcript) {
      setAnswer((p) => (p ? p + " " : "") + transcript);
      reset();
    }
  }, [listening, transcript, reset]);

  // Probe active session
  useEffect(() => {
    if (started) return;
    if (needsDomain && !domain) {
      setHasActive(false);
      return;
    }
    const key = `${category}:${domain ?? ""}:${difficulty}`;
    if (lastCheck.current === key) return;
    lastCheck.current = key;
    setHydrating(true);
    getActive({ data: { category, difficulty, domain: domain ?? null } })
      .then((r) => setHasActive(!!(r && r.turns.length > 0)))
      .catch(() => setHasActive(false))
      .finally(() => setHydrating(false));
  }, [category, difficulty, domain, started, needsDomain, getActive]);

  function maybeRamp(nextTurns: Turn[]): Difficulty {
    if (!autoRamp) return difficulty;
    const answered = nextTurns.filter((t) => t.feedback);
    if (answered.length === 0 || answered.length % 3 !== 0) return difficulty;
    const last3 = answered.slice(-3);
    const avg =
      last3.reduce(
        (a, t) =>
          a +
          ((t.feedback?.technicalAccuracyScore ?? t.feedback?.contentScore ?? 0) +
            (t.feedback?.confidenceScore ?? 0)) /
            2,
        0,
      ) / last3.length;
    if (avg >= 80 && difficulty !== "hard") return difficulty === "easy" ? "medium" : "hard";
    if (avg <= 50 && difficulty !== "easy") return difficulty === "hard" ? "medium" : "easy";
    return difficulty;
  }

  async function persist(nextTurns: Turn[], nextAsked: string[], sid: string | null, completed = false) {
    try {
      const r = await saveTurn({
        data: {
          sessionId: sid,
          category,
          difficulty,
          domain: domain ?? null,
          companyStyle: needsDomain ? companyStyle : null,
          turns: nextTurns,
          askedQuestions: nextAsked,
          completed,
        },
      });
      if (!sid) setSessionId(r.sessionId);
      if (typeof window !== "undefined") {
        localStorage.setItem(
          `lingua:interview:${category}${domain ? `:${domain}` : ""}`,
          r.sessionId,
        );
      }
    } catch (e) {
      console.error("save interview", e);
    }
  }

  async function startOrResume() {
    setBusy(true);
    try {
      const active = await getActive({ data: { category, difficulty, domain: domain ?? null } });
      if (active && active.turns.length > 0) {
        setSessionId(active.sessionId);
        setTurns(active.turns);
        setAskedQuestions(active.askedQuestions);
        setStarted(true);
        setResumed(true);
        const last = active.turns[active.turns.length - 1];
        if (last && !last.feedback) speak(last.question);
        return;
      }
      const r = await askFn({
        data: {
          category,
          difficulty,
          domain: needsDomain ? (domain as any) : undefined,
          companyStyle: needsDomain ? companyStyle : undefined,
          history: [],
          askedQuestions: [],
        },
      });
      const newAsked = [normalizeQ(r.question)];
      const newTurns: Turn[] = [{ question: r.question }];
      setTurns(newTurns);
      setAskedQuestions(newAsked);
      setSessionId(null);
      setStarted(true);
      setResumed(false);
      speak(r.question);
      await persist(newTurns, newAsked, null);
    } catch (e: any) {
      toast.error(e?.message || "Could not start");
    } finally {
      setBusy(false);
    }
  }

  async function submit() {
    const text = answer.trim();
    if (!text) return;
    const idx = turns.length - 1;
    const current = turns[idx];
    if (!current || current.feedback) return;
    setBusy(true);
    setAnswer("");
    try {
      const fb = await fbFn({
        data: { category, domain: domain ?? undefined, question: current.question, answer: text },
      });
      const updated = [...turns];
      updated[idx] = { ...current, answer: text, feedback: fb };
      setTurns(updated);
      const ramped = maybeRamp(updated);
      if (ramped !== difficulty) {
        setDifficulty(ramped);
        toast.success(`Difficulty → ${ramped}`);
      }
      await persist(updated, askedQuestions, sessionId);
    } catch (e: any) {
      toast.error(e?.message || "Could not get feedback");
    } finally {
      setBusy(false);
    }
  }

  async function next() {
    setBusy(true);
    try {
      const history = turns.flatMap((t) => {
        const arr: { role: "user" | "assistant"; content: string }[] = [{ role: "assistant", content: t.question }];
        if (t.answer) arr.push({ role: "user", content: t.answer });
        return arr;
      });
      const r = await askFn({
        data: {
          category,
          difficulty,
          domain: needsDomain ? (domain as any) : undefined,
          companyStyle: needsDomain ? companyStyle : undefined,
          history,
          askedQuestions,
        },
      });
      const newAsked = [...askedQuestions, normalizeQ(r.question)];
      const newTurns = [...turns, { question: r.question }];
      setTurns(newTurns);
      setAskedQuestions(newAsked);
      speak(r.question);
      await persist(newTurns, newAsked, sessionId);
    } catch (e: any) {
      toast.error(e?.message || "Could not fetch next");
    } finally {
      setBusy(false);
    }
  }

  async function doRestart() {
    setBusy(true);
    try {
      await restartFn({ data: { category, domain: domain ?? null } });
      if (typeof window !== "undefined") {
        localStorage.removeItem(`lingua:interview:${category}${domain ? `:${domain}` : ""}`);
      }
      setStarted(false);
      setResumed(false);
      setTurns([]);
      setAskedQuestions([]);
      setSessionId(null);
      setHasActive(false);
      setAnswer("");
      lastCheck.current = "";
      toast.success("Interview restarted");
    } catch (e: any) {
      toast.error(e?.message || "Could not restart");
    } finally {
      setBusy(false);
    }
  }

  const last = turns[turns.length - 1];
  const answeredCount = turns.filter((t) => t.feedback).length;
  const overall = turns
    .filter((t) => t.feedback)
    .reduce((acc, t) => { acc.c += t.feedback!.confidenceScore; acc.cn += 1; return acc; }, { c: 0, cn: 0 });
  const avgConfidence = overall.cn > 0 ? Math.round(overall.c / overall.cn) : 0;
  const progressPct = Math.min(100, Math.round((answeredCount / TARGET_QUESTIONS) * 100));
  const headerLabel = needsDomain && domain ? `${domain} Interview` : `${category} Interview`;

  return (
    <div className="container mx-auto px-6 py-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-aurora grid place-items-center">
          <Briefcase className="w-5 h-5 text-background" />
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Mock Interview</h1>
          <p className="text-sm text-muted-foreground">AI interviewer asks, you answer, AI scores. Progress is saved per domain.</p>
        </div>
      </div>

      {!started ? (
        <GlowCard>
          <h2 className="text-lg font-semibold mb-4">Configure your interview</h2>

          <div className="mb-4">
            <div className="text-xs font-mono-display text-muted-foreground mb-2">CATEGORY</div>
            <div className="flex gap-2 flex-wrap">
              {(["HR", "Technical", "General"] as Category[]).map((c) => (
                <button
                  key={c}
                  onClick={() => { setCategory(c); if (c !== "Technical") setDomain(null); }}
                  className={`text-sm px-4 py-2 rounded-lg transition ${
                    category === c ? "bg-gradient-aurora text-background" : "glass"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {needsDomain && (
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-mono-display text-muted-foreground">TECHNICAL DOMAIN</div>
                {domain && (
                  <button
                    onClick={() => setDomain(null)}
                    className="text-xs font-mono-display text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
                  >
                    <ArrowLeft className="w-3 h-3" /> Change
                  </button>
                )}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {CORE_DOMAINS.map(({ name, icon: Icon }) => {
                  const active = domain === name;
                  return (
                    <button
                      key={name}
                      onClick={() => setDomain(name)}
                      className={`group glass rounded-xl p-3 text-left transition hover:-translate-y-0.5 ${
                        active ? "ring-aurora bg-gradient-aurora/10" : ""
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-lg grid place-items-center ${
                          active ? "bg-gradient-aurora text-background" : "bg-secondary/60 text-foreground"
                        }`}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="text-sm font-medium">{name}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
              <button
                onClick={() => setShowMore((v) => !v)}
                className="text-xs font-mono-display text-muted-foreground hover:text-foreground mt-3"
              >
                {showMore ? "− Hide more domains" : "+ More domains"}
              </button>
              {showMore && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-2">
                  {MORE_DOMAINS.map(({ name, icon: Icon }) => {
                    const active = domain === name;
                    return (
                      <button
                        key={name}
                        onClick={() => setDomain(name)}
                        className={`group glass rounded-xl p-3 text-left transition hover:-translate-y-0.5 ${
                          active ? "ring-aurora bg-gradient-aurora/10" : ""
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div className={`w-8 h-8 rounded-lg grid place-items-center ${
                            active ? "bg-gradient-aurora text-background" : "bg-secondary/60 text-foreground"
                          }`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="text-sm font-medium">{name}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {needsDomain && (
            <div className="mb-4">
              <div className="text-xs font-mono-display text-muted-foreground mb-2">COMPANY STYLE</div>
              <div className="flex gap-2 flex-wrap">
                {(["product", "service", "startup"] as CompanyStyle[]).map((s) => (
                  <button
                    key={s}
                    onClick={() => setCompanyStyle(s)}
                    className={`text-sm px-4 py-2 rounded-lg capitalize transition ${
                      companyStyle === s ? "bg-gradient-aurora text-background" : "glass"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="mb-4">
            <div className="text-xs font-mono-display text-muted-foreground mb-2">DIFFICULTY</div>
            <div className="flex gap-2">
              {(["easy", "medium", "hard"] as Difficulty[]).map((d) => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={`text-sm px-4 py-2 rounded-lg capitalize transition ${
                    difficulty === d ? "bg-gradient-aurora text-background" : "glass"
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          <label className="flex items-center gap-2 text-xs font-mono-display text-muted-foreground mb-6 cursor-pointer">
            <input
              type="checkbox"
              checked={autoRamp}
              onChange={(e) => setAutoRamp(e.target.checked)}
              className="accent-current"
            />
            Auto-ramp difficulty based on my scores
          </label>

          <div className="flex flex-wrap gap-2 items-center">
            <Button
              onClick={startOrResume}
              disabled={busy || hydrating || !canConfigure}
              className="bg-gradient-aurora text-background"
            >
              {busy || hydrating ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : hasActive ? (
                <Play className="w-4 h-4 mr-2" />
              ) : (
                <Sparkles className="w-4 h-4 mr-2" />
              )}
              {hasActive ? "Continue Interview" : canConfigure ? "Start interview" : "Pick a domain"}
            </Button>
            {hasActive && (
              <Button variant="outline" onClick={doRestart} disabled={busy}>
                <RefreshCw className="w-4 h-4 mr-1.5" /> Restart
              </Button>
            )}
            {hasActive && !hydrating && (
              <span className="text-xs font-mono-display text-muted-foreground ml-1">
                Saved progress for {needsDomain && domain ? domain : category}
              </span>
            )}
          </div>
        </GlowCard>
      ) : (
        <div className="space-y-5">
          <GlowCard className="!p-4">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2 py-1 rounded-md glass text-xs font-mono-display">{category}</span>
                {domain && (
                  <span className="px-2 py-1 rounded-md text-xs font-mono-display bg-gradient-aurora text-background">
                    {domain}
                  </span>
                )}
                <span className={`px-2 py-1 rounded-md text-xs font-mono-display capitalize ${diffBadgeClass(difficulty)}`}>
                  {difficulty}
                </span>
                {needsDomain && (
                  <span className="px-2 py-1 rounded-md glass text-xs font-mono-display capitalize">{companyStyle}</span>
                )}
                {resumed && (
                  <span className="px-2 py-1 rounded-md text-xs font-mono-display bg-aurora-teal/15 text-aurora-teal">
                    Resumed
                  </span>
                )}
                <span className="flex items-center gap-1.5 text-xs font-mono-display text-muted-foreground">
                  <span className="w-1.5 h-1.5 rounded-full bg-aurora-pink animate-pulse" />
                  Active
                </span>
              </div>
              <div className="flex items-center gap-2">
                {avgConfidence > 0 && (
                  <span className="text-xs font-mono-display text-muted-foreground">
                    Avg: <span className="text-gradient-aurora font-bold">{avgConfidence}</span>
                  </span>
                )}
                <Button size="sm" variant="ghost" onClick={doRestart} disabled={busy}>
                  <RefreshCw className="w-4 h-4 mr-1.5" />Restart
                </Button>
              </div>
            </div>
            <div className="text-xs font-mono-display text-muted-foreground mb-1.5">
              {headerLabel} – {answeredCount}/{TARGET_QUESTIONS} Questions Completed
            </div>
            <Progress value={progressPct} className="h-1.5" />
          </GlowCard>

          {turns.map((t, i) => (
            <div key={i} className="space-y-3">
              <GlowCard>
                <div className="text-xs font-mono-display text-muted-foreground mb-1">INTERVIEWER · Q{i + 1}</div>
                <div className="text-base whitespace-pre-wrap">{t.question}</div>
                {!t.answer && (
                  <Button size="sm" variant="ghost" className="mt-2" onClick={() => speak(t.question)}>🔊 Hear question</Button>
                )}
              </GlowCard>
              {t.answer && (
                <GlowCard className="!bg-secondary/40">
                  <div className="text-xs font-mono-display text-muted-foreground mb-1">YOU</div>
                  <div className="text-sm whitespace-pre-wrap">{t.answer}</div>
                </GlowCard>
              )}
              {t.feedback && (
                <>
                  <div className={`grid gap-3 ${t.feedback.technicalAccuracyScore != null ? "grid-cols-2 md:grid-cols-4" : "grid-cols-3"}`}>
                    {t.feedback.technicalAccuracyScore != null && (
                      <Score label="Technical" v={t.feedback.technicalAccuracyScore} />
                    )}
                    <Score label="Confidence" v={t.feedback.confidenceScore} />
                    <Score label="Content" v={t.feedback.contentScore} />
                    <Score label="Language" v={t.feedback.languageScore} />
                  </div>
                  {t.feedback.strengths?.length > 0 && (
                    <GlowCard className="border-l-2 border-aurora-teal !p-4">
                      <div className="text-xs font-mono-display text-aurora-teal mb-1.5">STRENGTHS</div>
                      <ul className="text-sm space-y-1 list-disc list-inside">
                        {t.feedback.strengths.map((s: string, j: number) => <li key={j}>{s}</li>)}
                      </ul>
                    </GlowCard>
                  )}
                  {t.feedback.improvements?.length > 0 && (
                    <GlowCard className="border-l-2 border-aurora-pink !p-4">
                      <div className="text-xs font-mono-display text-aurora-pink mb-1.5">IMPROVE</div>
                      <ul className="text-sm space-y-1 list-disc list-inside">
                        {t.feedback.improvements.map((s: string, j: number) => <li key={j}>{s}</li>)}
                      </ul>
                    </GlowCard>
                  )}
                  <GlowCard className="border-l-2 border-aurora-purple !p-4">
                    <div className="text-xs font-mono-display text-aurora-purple mb-1.5">MODEL ANSWER</div>
                    <p className="text-sm whitespace-pre-wrap">{t.feedback.modelAnswer}</p>
                  </GlowCard>
                </>
              )}
            </div>
          ))}

          {last && !last.feedback ? (
            <GlowCard>
              <div className="text-xs font-mono-display text-muted-foreground mb-2">YOUR ANSWER</div>
              <Textarea
                value={answer + (interim ? " " + interim : "")}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="Speak or type your answer…"
                rows={5}
              />
              <div className="flex items-center justify-between mt-3">
                {supported ? (
                  <Button size="sm" variant={listening ? "destructive" : "outline"} onClick={listening ? stop : start} className={listening ? "animate-pulse-glow" : ""}>
                    {listening ? <><MicOff className="w-4 h-4 mr-1.5" /> Stop</> : <><Mic className="w-4 h-4 mr-1.5" /> Speak</>}
                  </Button>
                ) : <span />}
                <Button onClick={submit} disabled={busy || !answer.trim()} className="bg-gradient-aurora text-background">
                  {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                  Submit answer
                </Button>
              </div>
            </GlowCard>
          ) : (
            <Button onClick={next} disabled={busy} className="bg-gradient-aurora text-background">
              {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
              Next question
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

function Score({ label, v }: { label: string; v: number }) {
  return (
    <GlowCard className="!p-3 text-center">
      <div className="text-[10px] font-mono-display text-muted-foreground">{label}</div>
      <div className="text-2xl font-bold text-gradient-aurora">{v}</div>
      <Progress value={v} className="h-1 mt-1" />
    </GlowCard>
  );
}
