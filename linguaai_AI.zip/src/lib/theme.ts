export function applyTheme(theme: "dark" | "light") {
  const root = document.documentElement;
  root.classList.remove("dark", "light");
  root.classList.add(theme);
  try {
    localStorage.setItem("aet:theme", theme);
  } catch {}
}

export function getInitialTheme(): "dark" | "light" {
  if (typeof window === "undefined") return "dark";
  try {
    const stored = localStorage.getItem("aet:theme");
    if (stored === "light" || stored === "dark") return stored;
  } catch {}
  return "dark";
}
