import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { aiChat, aiJSON, type ChatMsg } from "./ai.server";

/* ========== Chat tutor (returns reply + correction + better phrasing) ========== */

const chatInput = z.object({
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
    .max(40),
  level: z.enum(["beginner", "intermediate", "advanced"]).default("beginner"),
});

export const chatTutor = createServerFn({ method: "POST" })
  .inputValidator((d) => chatInput.parse(d))
  .handler(async ({ data }) => {
    const sys = `You are an enthusiastic English-speaking tutor for a ${data.level} learner. 
Keep replies short (1-3 sentences), warm, and natural. Encourage continued conversation by asking a follow-up question.`;

    const messages: ChatMsg[] = [
      { role: "system", content: sys },
      ...data.history,
    ];

    type Out = { correction: string; betterPhrasing: string; reply: string };
    return aiJSON<Out>(
      [
        ...messages,
        {
          role: "system",
          content:
            "Now respond. ALSO assess the user's last message: provide a short grammar correction (or empty string if perfect) and a more natural rephrasing (or empty string if already natural).",
        },
      ],
      "tutor_reply",
      {
        type: "object",
        properties: {
          correction: { type: "string", description: "Grammar/spelling correction of user's last message. Empty string if none." },
          betterPhrasing: { type: "string", description: "More natural way to say it. Empty if already great." },
          reply: { type: "string", description: "Your conversational reply." },
        },
        required: ["correction", "betterPhrasing", "reply"],
        additionalProperties: false,
      },
    );
  });

/* ========== Voice practice feedback ========== */

const voiceInput = z.object({
  topic: z.string().max(200),
  transcript: z.string().min(1).max(4000),
});

export const voiceFeedback = createServerFn({ method: "POST" })
  .inputValidator((d) => voiceInput.parse(d))
  .handler(async ({ data }) => {
    type Out = {
      fluencyScore: number;
      grammarScore: number;
      vocabScore: number;
      issues: string[];
      suggestions: string[];
      modelAnswer: string;
      summary: string;
    };
    return aiJSON<Out>(
      [
        {
          role: "system",
          content:
            "You are an English speaking coach. Analyze the learner's spoken response on the given topic and return scores 0-100 with concise, encouraging feedback.",
        },
        { role: "user", content: `Topic: ${data.topic}\n\nMy response:\n${data.transcript}` },
      ],
      "speaking_feedback",
      {
        type: "object",
        properties: {
          fluencyScore: { type: "integer", minimum: 0, maximum: 100 },
          grammarScore: { type: "integer", minimum: 0, maximum: 100 },
          vocabScore: { type: "integer", minimum: 0, maximum: 100 },
          issues: { type: "array", items: { type: "string" }, maxItems: 5 },
          suggestions: { type: "array", items: { type: "string" }, maxItems: 5 },
          modelAnswer: { type: "string", description: "A natural, fluent native-English version of an answer to the topic." },
          summary: { type: "string" },
        },
        required: ["fluencyScore", "grammarScore", "vocabScore", "issues", "suggestions", "modelAnswer", "summary"],
        additionalProperties: false,
      },
    );
  });

/* ========== Telugu → English ========== */

const teluguInput = z.object({ input: z.string().min(1).max(2000) });

export const teluguHelper = createServerFn({ method: "POST" })
  .inputValidator((d) => teluguInput.parse(d))
  .handler(async ({ data }) => {
    type Out = {
      teluguScript: string;
      transliteration: string;
      literalEnglish: string;
      fluentEnglish: string;
      explanation: string;
      tips: string[];
    };
    return aiJSON<Out>(
      [
        {
          role: "system",
          content:
            "You are a Telugu-to-English tutor. Input may be Telugu script, transliterated Telugu (Roman letters), or mixed Telugu/English. Produce structured output that helps the learner speak fluent English.",
        },
        { role: "user", content: data.input },
      ],
      "telugu_to_english",
      {
        type: "object",
        properties: {
          teluguScript: { type: "string", description: "Original/normalized Telugu in Telugu script." },
          transliteration: { type: "string", description: "Romanized Telugu pronunciation." },
          literalEnglish: { type: "string", description: "Word-for-word literal English translation." },
          fluentEnglish: { type: "string", description: "Natural, fluent English a native speaker would use." },
          explanation: { type: "string", description: "Brief, simple explanation of differences/mistakes (in English)." },
          tips: { type: "array", items: { type: "string" }, maxItems: 4 },
        },
        required: ["teluguScript", "transliteration", "literalEnglish", "fluentEnglish", "explanation", "tips"],
        additionalProperties: false,
      },
    );
  });

/* ========== Mock interview ========== */

const TechDomain = z.enum([
  "C Programming",
  "Python",
  "Java",
  "DSA",
  "DBMS",
  "Operating Systems",
  "Computer Networks",
  "Web Development",
  "SQL",
  "React",
  "Machine Learning",
]);
const CompanyStyle = z.enum(["product", "service", "startup"]);

const interviewQInput = z.object({
  category: z.enum(["HR", "Technical", "General"]),
  difficulty: z.enum(["easy", "medium", "hard"]).default("medium"),
  domain: TechDomain.optional(),
  companyStyle: CompanyStyle.optional(),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
    .max(40),
  askedQuestions: z.array(z.string()).max(200).default([]),
});

export const interviewNextQuestion = createServerFn({ method: "POST" })
  .inputValidator((d) => interviewQInput.parse(d))
  .handler(async ({ data }) => {
    let sys: string;
    if (data.category === "Technical" && data.domain) {
      const style = data.companyStyle ?? "product";
      const styleLabel =
        style === "product" ? "product-based" : style === "service" ? "service-based" : "startup";
      sys = `You are a senior technical interviewer at a ${styleLabel} company, specializing in ${data.domain}. Difficulty: ${data.difficulty}.
Rules:
- Ask ONE focused question at a time. Do NOT provide the answer.
- Only ask frequently-asked, real-company interview questions for ${data.domain} (LeetCode-style conceptual + problem-solving + scenario + complexity/trade-off).
- Cover core fundamentals first, then deeper concepts, then problem-solving / optimization.
- Keep wording concise and professional, like a real interviewer.
- Mix conceptual ("explain X"), comparison ("difference between X and Y"), and applied ("how would you design / optimize…") questions.
- Never ask non-${data.domain} questions.`;
    } else {
      sys = `You are a friendly but realistic ${data.category} interviewer at ${data.difficulty} difficulty. Ask one focused question at a time. Do not provide answers. Keep questions concise.`;
    }
    const messages: ChatMsg[] = [
      { role: "system", content: sys },
      ...data.history,
    ];
    if (data.askedQuestions.length > 0) {
      messages.push({
        role: "system",
        content:
          "Do NOT repeat or paraphrase any of these previously asked questions. Pick a fresh, different question:\n- " +
          data.askedQuestions.slice(-60).join("\n- "),
      });
    }
    messages.push({
      role: "user",
      content:
        data.history.length === 0 && data.askedQuestions.length === 0
          ? "Start the interview with a warm opener."
          : "Ask the next question.",
    });
    const txt = await aiChat(messages);
    return { question: txt.trim() };
  });

const interviewFbInput = z.object({
  category: z.enum(["HR", "Technical", "General"]),
  domain: z.string().optional(),
  question: z.string(),
  answer: z.string().min(1).max(4000),
});

export const interviewFeedback = createServerFn({ method: "POST" })
  .inputValidator((d) => interviewFbInput.parse(d))
  .handler(async ({ data }) => {
    const isTech = data.category === "Technical";
    type Out = {
      confidenceScore: number;
      contentScore: number;
      languageScore: number;
      technicalAccuracyScore?: number;
      strengths: string[];
      improvements: string[];
      modelAnswer: string;
    };
    const properties: Record<string, any> = {
      confidenceScore: { type: "integer", minimum: 0, maximum: 100 },
      contentScore: { type: "integer", minimum: 0, maximum: 100 },
      languageScore: { type: "integer", minimum: 0, maximum: 100 },
      strengths: { type: "array", items: { type: "string" }, maxItems: 4 },
      improvements: { type: "array", items: { type: "string" }, maxItems: 4 },
      modelAnswer: { type: "string", description: "A strong sample answer in fluent English." },
    };
    const required = ["confidenceScore", "contentScore", "languageScore", "strengths", "improvements", "modelAnswer"];
    if (isTech) {
      properties.technicalAccuracyScore = { type: "integer", minimum: 0, maximum: 100 };
      required.push("technicalAccuracyScore");
    }
    const sys = isTech
      ? `You are a senior technical interviewer${data.domain ? ` for ${data.domain}` : ""}. Evaluate the candidate's answer for technical correctness AND communication. Provide structured, actionable feedback. Scores 0-100. The model answer must be a strong, professional answer with correct technical detail.`
      : `You are a senior ${data.category} interviewer. Evaluate the candidate's answer and provide structured, actionable feedback. Scores 0-100.`;
    return aiJSON<Out>(
      [
        { role: "system", content: sys },
        { role: "user", content: `Question: ${data.question}\n\nMy answer: ${data.answer}` },
      ],
      "interview_feedback",
      { type: "object", properties, required, additionalProperties: false },
    );
  });
