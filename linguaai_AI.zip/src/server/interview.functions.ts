import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Category = z.enum(["HR", "Technical", "General"]);
const Difficulty = z.enum(["easy", "medium", "hard"]);
const Domain = z.string().min(1).max(60);
const CompanyStyle = z.enum(["product", "service", "startup"]);

const TurnSchema = z.object({
  question: z.string(),
  answer: z.string().optional(),
  feedback: z.any().optional(),
});

function sessionType(category: string, domain?: string | null) {
  if (category === "Technical" && domain) return `interview:Technical:${domain}`;
  return `interview:${category}`;
}

export const getActiveInterview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        category: Category,
        difficulty: Difficulty,
        domain: Domain.optional().nullable(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: rows, error } = await supabase
      .from("sessions")
      .select("id, metadata, score, summary, created_at")
      .eq("user_id", userId)
      .eq("type", sessionType(data.category, data.domain))
      .order("created_at", { ascending: false })
      .limit(1);
    if (error) throw new Error(error.message);
    const row = rows?.[0];
    if (!row) return null;
    const meta = (row.metadata ?? {}) as any;
    if (meta.completed) return null;
    if (meta.difficulty && meta.difficulty !== data.difficulty) return null;
    return {
      sessionId: row.id,
      turns: (meta.turns ?? []) as Array<z.infer<typeof TurnSchema>>,
      askedQuestions: (meta.askedQuestions ?? []) as string[],
      difficulty: (meta.difficulty ?? data.difficulty) as z.infer<typeof Difficulty>,
      domain: (meta.domain ?? data.domain ?? null) as string | null,
      companyStyle: (meta.companyStyle ?? null) as z.infer<typeof CompanyStyle> | null,
    };
  });

export const saveInterviewTurn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        sessionId: z.string().uuid().optional().nullable(),
        category: Category,
        difficulty: Difficulty,
        domain: Domain.optional().nullable(),
        companyStyle: CompanyStyle.optional().nullable(),
        turns: z.array(TurnSchema),
        askedQuestions: z.array(z.string()),
        completed: z.boolean().optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const answered = data.turns.filter((t) => t.feedback);
    const avg =
      answered.length > 0
        ? Math.round(
            answered.reduce(
              (a, t) => a + (t.feedback?.confidenceScore ?? 0),
              0,
            ) / answered.length,
          )
        : null;
    const metadata = {
      difficulty: data.difficulty,
      domain: data.domain ?? null,
      companyStyle: data.companyStyle ?? null,
      turns: data.turns,
      askedQuestions: data.askedQuestions,
      completed: !!data.completed,
    };
    const summary = `${answered.length} answered`;
    const title =
      data.category === "Technical" && data.domain
        ? `${data.domain} Technical Interview`
        : `${data.category} Interview`;

    if (data.sessionId) {
      const { error } = await supabase
        .from("sessions")
        .update({ metadata, score: avg, summary })
        .eq("id", data.sessionId)
        .eq("user_id", userId);
      if (error) throw new Error(error.message);
      return { sessionId: data.sessionId };
    }
    const { data: inserted, error } = await supabase
      .from("sessions")
      .insert({
        user_id: userId,
        type: sessionType(data.category, data.domain),
        title,
        metadata,
        score: avg,
        summary,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { sessionId: inserted.id };
  });

export const restartInterview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ category: Category, domain: Domain.optional().nullable() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: rows, error } = await supabase
      .from("sessions")
      .select("id, metadata")
      .eq("user_id", userId)
      .eq("type", sessionType(data.category, data.domain));
    if (error) throw new Error(error.message);
    for (const r of rows ?? []) {
      const meta = { ...((r.metadata ?? {}) as any), completed: true };
      await supabase.from("sessions").update({ metadata: meta }).eq("id", r.id);
    }
    return { ok: true };
  });
