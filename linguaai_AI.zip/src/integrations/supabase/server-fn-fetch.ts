import { supabase } from "./client";

let installed = false;

/**
 * Patches window.fetch so any request to /_serverFn/* automatically
 * carries the current Supabase session as a Bearer token. This is
 * required for server functions protected by `requireSupabaseAuth`.
 */
export function installServerFnAuth() {
  if (installed) return;
  if (typeof window === "undefined") return;
  installed = true;

  const originalFetch = window.fetch.bind(window);

  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    try {
      const url =
        typeof input === "string"
          ? input
          : input instanceof URL
            ? input.toString()
            : (input as Request).url;

      const isServerFn =
        url.includes("/_serverFn/") ||
        url.startsWith("/_serverFn/");

      if (isServerFn) {
        const headers = new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined));
        if (!headers.has("authorization")) {
          const { data } = await supabase.auth.getSession();
          const token = data.session?.access_token;
          if (token) headers.set("authorization", `Bearer ${token}`);
        }
        return originalFetch(input as any, { ...(init ?? {}), headers });
      }
    } catch {
      // fall through to default fetch
    }
    return originalFetch(input as any, init);
  };
}
