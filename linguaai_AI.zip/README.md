# LinguaAI

A futuristic, AI-powered English learning and interview preparation platform built with TanStack Start, React 19, Tailwind CSS v4, and Supabase (Lovable Cloud).

Founder: **Lokeswari Manchem**

## Features
- AI Chat tutor (grammar, vocabulary, conversation)
- Voice practice with speech recognition
- AI Mock Interview (HR / Technical / General) with persistent progress
- Technical interview domains (Python, Java, C, DSA, DBMS, …) with company-style modes
- Dashboard with stats, History of past sessions
- Telugu-language practice mode
- Dark / light theme, responsive design

## Tech stack
- TanStack Start v1 (React 19, Vite 7)
- Tailwind CSS v4
- Supabase (auth, database, RLS)
- Lovable AI Gateway (server-side AI)
- shadcn/ui components

## Getting started
1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy `.env.example` to `.env` and fill in your own backend values:
   ```bash
   cp .env.example .env
   ```
   If you are on Lovable, connect your backend in Lovable Cloud and the values are filled automatically. If you are self-hosting, create a Supabase project and paste your URL + publishable (anon) key.
3. Run the dev server:
   ```bash
   npm run dev
   ```

## Project structure
```
src/
  routes/         app pages (landing, login, signup, _app/* features)
  server/          server functions (AI, interview logic)
  components/      UI + layout components
  integrations/    supabase + lovable clients
  lib/             auth, theme, utils
supabase/
  migrations/      database schema
  config.toml      supabase config
```

## Notes
- All AI calls run server-side through the Lovable AI Gateway; no API keys are exposed to the browser.
- Database tables use Row Level Security so each user only sees their own data.
- `.env` is excluded from this archive to keep credentials safe.
